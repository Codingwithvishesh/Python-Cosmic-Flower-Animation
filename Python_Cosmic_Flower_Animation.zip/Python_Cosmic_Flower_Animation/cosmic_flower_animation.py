﻿import turtle as t
import math as m
import time
import colorsys

# --- Configuration ---
WIDTH, HEIGHT = 800, 800
BG_COLOR = "#050505"
CENTER_FLOWER_COLOR = "#FF00FF"
NUM_ARMS = 6
LAYERS_PER_ARM = 30
R = 280
R_INNER = R / m.sqrt(3)
# Calculated delay for ~13 second total animation
FRAME_DELAY = 0.06 

# --- Setup Screen ---
s = t.Screen()
s.setup(WIDTH, HEIGHT)
s.bgcolor(BG_COLOR)
s.tracer(0)
s.title("Cosmic Flower Animation")

# --- Setup Turtle ---
p = t.Turtle()
p.hideturtle()
p.speed(0)

# --- Helper Functions ---
def draw_central_flower():
    p.penup()
    p.goto(0, -20)
    p.pendown()
    p.color(CENTER_FLOWER_COLOR)
    # Draw gradually
    for i in range(7):
        p.circle(20, 360/7)
        s.update()
        time.sleep(0.1)

# --- Main Animation ---
def animate():
    draw_central_flower()
    
    for k in range(NUM_ARMS):
        hue = k / NUM_ARMS
        rgb = colorsys.hsv_to_rgb(hue, 0.8, 1.0)
        p.pencolor(rgb)
        
        a_tip = m.radians(k * 60)
        a_left = m.radians(k * 60 - 30)
        a_right = m.radians(k * 60 + 30)

        P_tip = (R * m.cos(a_tip), R * m.sin(a_tip))
        P_left = (R_INNER * m.cos(a_left), R_INNER * m.sin(a_left))
        P_right = (R_INNER * m.cos(a_right), R_INNER * m.sin(a_right))

        # Main Arm Outline - Drawn slowly
        p.width(3)
        p.penup()
        p.goto(0, 0)
        p.pendown()
        p.goto(P_left)
        s.update()
        time.sleep(FRAME_DELAY)
        p.goto(P_tip)
        s.update()
        time.sleep(FRAME_DELAY)
        p.goto(P_right)
        s.update()
        time.sleep(FRAME_DELAY)
        p.goto(0, 0)
        s.update()

        # Layered Pattern - Drawn smoothly
        p.width(1.2)
        for i in range(LAYERS_PER_ARM, 0, -1):
            ratio = i / LAYERS_PER_ARM
            L_pt = (P_left[0] + ratio * (P_tip[0] - P_left[0]), P_left[1] + ratio * (P_tip[1] - P_left[1]))
            R_pt = (P_right[0] + ratio * (P_tip[0] - P_right[0]), P_right[1] + ratio * (P_tip[1] - P_right[1]))
            V_L = (ratio * P_left[0], ratio * P_left[1])
            V_R = (ratio * P_right[0], ratio * P_right[1])

            p.penup()
            p.goto(V_L)
            p.pendown()
            p.goto(L_pt)
            p.goto(R_pt)
            p.goto(V_R)
            
            s.update()
            time.sleep(0.01) # Very short delay for smooth layer transition

        time.sleep(0.3) # Pause after each arm for artistic effect

animate()
t.done()
